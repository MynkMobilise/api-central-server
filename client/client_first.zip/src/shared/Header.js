import React from "react";
import { Link } from "react-router-dom";
import HeaderScss from "../../src/assets/scss/Header.module.scss";
import { useState } from "react";

export default function Header() {

    const [mode, setMode] = useState('text'); 
  const toggleMode = (newMode) => {
    setMode(newMode);
    console.log('Selected Mode:', newMode);
  };
  return (
    <>
      {/* <!-- Topbar --> */}
      <nav
        className={`navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow ${HeaderScss["navbar-wrapper"]}`}
      >
        {/* <!-- Sidebar Toggle (Topbar) --> */}
        {/* <button id="sidebarToggleTop" className="btn btn-link d-md-none rounded-circle mr-3">
                        <i className="fa fa-bars"></i>
                    </button> */}

        {/* <!-- Topbar Search --> */}
        {/* <form
                        className="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div className="input-group">
                            <input type="text" className="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2" />
                            <div className="input-group-append">
                                <button className="btn btn-primary" type="button">
                                    <i className="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form> */}

        {/* <!-- Topbar Navbar --> */}
        <ul className="navbar-nav ml-auto">
          {/* <!-- Nav Item - Search Dropdown (Visible Only XS) --> */}
          {/* <li className="nav-item dropdown no-arrow d-sm-none">
                            <Link className="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fas fa-search fa-fw"></i>
                            </Link>
                            <div className="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form className="form-inline mr-auto w-100 navbar-search">
                                    <div className="input-group">
                                        <input type="text" className="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-primary" type="button">
                                                <i className="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li> */}

          <li>
          <div className={HeaderScss['toggle-container']}>
      <div
        className={`${HeaderScss['toggle-button']} ${mode === 'text' ? HeaderScss.active : ''}`}
        onClick={() => toggleMode('text')}
      >
        Test Mode
      </div>
      <div
        className={`${HeaderScss['toggle-button']} ${mode === 'live' ? HeaderScss.active : ''}`}
        onClick={() => toggleMode('live')}
      >
        Live Mode
      </div>
    </div>
          </li>

          <li className="nav-item mr-5 d-flex align-items-center">
            <p
              className={`mb-0 mr-3 text-gray font-weight-thick ${HeaderScss["header-text"]}`}
            >
              {" "}
              Testing Credits
            </p>
            <button
              className={`btn font-weight-thick ${HeaderScss["header-btn"]}`}
            >
              260
            </button>
          </li>

          {/* <!-- Nav Item - Alerts --> */}
          <li className="nav-item dropdown no-arrow ml-4 mr-2">
            <Link
              className="nav-link dropdown-toggle"
              href="#"
              id="alertsDropdown"
              role="button"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              <img src="/assets/img/bell-icon.svg" alt="" />
              {/* <!-- Counter - Alerts --> */}
              <span className="badge badge-danger badge-counter">3</span>
            </Link>
            {/* <!-- Dropdown - Alerts --> */}
            {/* <div className="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 className="dropdown-header">
                                    Alerts Center
                                </h6>
                                <Link className="dropdown-item d-flex align-items-center" href="#">
                                    <div className="mr-3">
                                        <div className="icon-circle bg-primary">
                                            <i className="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="small text-gray-500">December 12, 2019</div>
                                        <span className="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </Link>
                                <Link className="dropdown-item d-flex align-items-center" href="#">
                                    <div className="mr-3">
                                        <div className="icon-circle bg-success">
                                            <i className="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </Link>
                                <Link className="dropdown-item d-flex align-items-center" href="#">
                                    <div className="mr-3">
                                        <div className="icon-circle bg-warning">
                                            <i className="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </Link>
                                <Link className="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</Link>
                            </div> */}
          </li>

          {/* <!-- Nav Item - Messages --> */}
          {/* <li className="nav-item dropdown no-arrow mx-1">
                            <Link className="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fas fa-envelope fa-fw"></i>
                                <span className="badge badge-danger badge-counter">7</span>
                            </Link>
                            <div className="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="messagesDropdown">
                                <h6 className="dropdown-header">
                                    Message Center
                                </h6>
                                <Link className="dropdown-item d-flex align-items-center" href="#">
                                    <div className="dropdown-list-image mr-3">
                                        <img className="rounded-circle" src="assets/img/undraw_profile_3.svg"
                                            alt="altimg"/>
                                        <div className="status-indicator bg-warning"></div>
                                    </div>
                                    <div>
                                        <div className="text-truncate">Last month's report looks great, I am very happy with
                                            the progress so far, keep up the good work!</div>
                                        <div className="small text-gray-500">Morgan Alvarez · 2d</div>
                                    </div>
                                </Link>
                                <Link className="dropdown-item d-flex align-items-center" href="#">
                                    <div className="dropdown-list-image mr-3">
                                        <img className="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                                            alt="..." />
                                        <div className="status-indicator bg-success"></div>
                                    </div>
                                    <div>
                                        <div className="text-truncate">Am I a good boy? The reason I ask is because someone
                                            told me that people say this to all dogs, even if they aren't good...</div>
                                        <div className="small text-gray-500">Chicken the Dog · 2w</div>
                                    </div>
                                </Link>
                                <Link className="dropdown-item text-center small text-gray-500" href="#">Read More Messages</Link>
                            </div>
                        </li> */}

          {/* <div className="topbar-divider d-none d-sm-block"></div> */}

          {/* <!-- Nav Item - User Information --> */}
          <li className="nav-item dropdown no-arrow">
            <Link
              className="nav-link dropdown-toggle"
              href="#"
              id="userDropdown"
              role="button"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              <img
                alt=""
                className="img-profile rounded-circle"
                src="/assets/img/person.svg"
              />
            </Link>
          </li>
          {/* <!-- Nav Item - User Information --> */}
          {/* <li className="nav-item dropdown no-arrow">
                            <Link className="nav-link" href="javascript:void" (click)="openNav()" role="button">
                                <i className="fa fa-bars"></i>
                            </Link>
                        </li> */}
        </ul>
      </nav>
      {/* <!-- End of Topbar --> */}
    </>
  );
}
