import React from 'react'

export default function AiStudioApi() {
  return (
    <div>AiStudioApi</div>
  )
}
