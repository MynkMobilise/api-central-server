import React from "react";

export default function DirectorVerification() {
  return <div>DirectorVerification</div>;
}
