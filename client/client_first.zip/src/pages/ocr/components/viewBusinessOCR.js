import React from 'react'

const viewBusinessOCR = () => {
  return (
    <div>
      
    </div>
  )
}

export default viewBusinessOCR
